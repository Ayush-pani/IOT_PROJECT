from flask import Flask, render_template_string
import sqlite3
import random
import datetime

app = Flask(__name__)
DB_NAME = "smart_waste.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS waste_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            bin_id TEXT,
            fill_level INTEGER,
            gas_level INTEGER,
            temperature REAL,
            humidity REAL
        )
    ''')
    conn.commit()

    cursor.execute("SELECT COUNT(*) FROM waste_data")
    if cursor.fetchone()[0] == 0:
        bin_ids = ['BIN_A1', 'BIN_B2', 'BIN_C3']
        for _ in range(10):
            for bin_id in bin_ids:
                timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                fill_level = random.randint(10, 100)
                gas_level = random.randint(0, 10)
                temperature = round(random.uniform(25, 35), 2)
                humidity = round(random.uniform(40, 70), 2)
                cursor.execute('''
                    INSERT INTO waste_data (timestamp, bin_id, fill_level, gas_level, temperature, humidity)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (timestamp, bin_id, fill_level, gas_level, temperature, humidity))
        conn.commit()
    conn.close()

def fetch_data():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT bin_id, timestamp, fill_level, gas_level, temperature, humidity
        FROM waste_data
        ORDER BY timestamp DESC
        LIMIT 50
    ''')
    data = cursor.fetchall()
    conn.close()
    return data

def get_average_fill_levels():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT bin_id, AVG(fill_level)
        FROM waste_data
        GROUP BY bin_id
    ''')
    results = cursor.fetchall()
    conn.close()
    labels = [row[0] for row in results]
    values = [round(row[1], 2) for row in results]
    return labels, values

@app.route('/')
def index():
    data = fetch_data()
    labels, values = get_average_fill_levels()
    return render_template_string(TEMPLATE, data=data, labels=labels, values=values)

TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Smart Waste Monitoring</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            padding: 40px;
            background-color: #121212;
            color: #e0f2f1;
        }
        h1 {
            text-align: center;
            color: #00e676;
        }
        .chart-container {
            width: 80%;
            margin: 30px auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #1e1e1e;
            margin-top: 30px;
            box-shadow: 0 0 15px rgba(0,255,0,0.2);
        }
        th, td {
            padding: 14px;
            border: 1px solid #2e7d32;
            text-align: center;
        }
        th {
            background-color: #004d40;
            color: #a5d6a7;
        }
        tr:nth-child(even) {
            background-color: #1b1b1b;
        }
        tr:nth-child(odd) {
            background-color: #212121;
        }
        .alert {
            background-color: #b71c1c;
            color: white;
            font-weight: bold;
        }
        p {
            text-align: center;
            color: #81c784;
        }
    </style>
</head>
<body>
    <h1>Smart Waste Monitoring Dashboard</h1>

    <div class="chart-container">
        <canvas id="fillChart"></canvas>
    </div>

    <p>Red rows indicate bins that are over 80% full.</p>
    <table>
        <thead>
            <tr>
                <th>Bin ID</th>
                <th>Timestamp</th>
                <th>Fill Level (%)</th>
                <th>Gas Level</th>
                <th>Temperature (°C)</th>
                <th>Humidity (%)</th>
            </tr>
        </thead>
        <tbody>
            {% for row in data %}
            <tr class="{{ 'alert' if row[2] > 80 else '' }}">
                <td>{{ row[0] }}</td>
                <td>{{ row[1] }}</td>
                <td>{{ row[2] }}</td>
                <td>{{ row[3] }}</td>
                <td>{{ row[4] }}</td>
                <td>{{ row[5] }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>

    <script>
        const ctx = document.getElementById('fillChart').getContext('2d');
        const fillChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: {{ labels | safe }},
                datasets: [{
                    label: 'Average Fill Level (%)',
                    data: {{ values | safe }},
                    backgroundColor: '#00e676',
                    borderColor: '#00c853',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: {
                            color: '#a5d6a7'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#a5d6a7' }
                    },
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: { color: '#a5d6a7' }
                    }
                }
            }
        });
    </script>
</body>
</html>
'''

if __name__ == '__main__':
    init_db()
    app.run(debug=True)

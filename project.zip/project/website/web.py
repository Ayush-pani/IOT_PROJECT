from flask import Flask, render_template
import pyrebase

app = Flask(__name__)
firebaseConfig = {
     "apiKey": "AIzaSyAf5LDV_L7mGUj3q-zW8OuH5Y8Jg_18y-0",
    "authDomain": "ayush.firebaseapp.com",
    "databaseURL": "https://ayush-169c4-default-rtdb.asia-southeast1.firebasedatabase.app",
    "storageBucket": "ayush-169c4.appspot.com"
}
# config = {
#     "apiKey": "AIzaSyAf5LDV_L7mGUj3q-zW8OuH5Y8Jg_18y-0",
#     "authDomain": "ayush.firebaseapp.com",
#     "databaseURL": "https://ayush-169c4-default-rtdb.asia-southeast1.firebasedatabase.app",
#     "storageBucket": "ayush-169c4.appspot.com"
# }

firebase = pyrebase.initialize_app(firebaseConfig)
db = firebase.database()

@app.route('/')
def index():
    dht11 = db.child("DHT11").get().val()
    motor = db.child("Motor").get().val()
    rain = db.child("RainSensor").get().val()
    soil = db.child("SoilSensor").get().val()
    water_flow = db.child("WaterFlowSensor").get().val()

    return render_template("index.html",
                           dht11=dht11,
                           motor=motor,
                           rain=rain,
                           soil=soil,
                           water_flow=water_flow)

if __name__ == '__main__':
    app.run(debug=True)

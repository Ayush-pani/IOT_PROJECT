import sqlite3
import random
from datetime import datetime
import time

conn = sqlite3.connect("health_data.db")
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS health_monitor (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        heart_rate INTEGER,
        body_temp REAL,
        spo2 INTEGER,
        stress_level INTEGER
    )
''')
conn.commit()

def generate_health_data():
    """Simulate realistic health data."""
    heart_rate = random.randint(60, 100)               
    body_temp = round(random.uniform(97.5, 99.5), 2)    
    spo2 = random.randint(95, 100)                      
    stress = random.randint(20, 80)                     
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return (timestamp, heart_rate, body_temp, spo2, stress)

def insert_data_to_db(data):
    """Insert a row of data into the database."""
    cursor.execute('''
        INSERT INTO health_monitor (timestamp, heart_rate, body_temp, spo2, stress_level)
        VALUES (?, ?, ?, ?, ?)
    ''', data)
    conn.commit()

if __name__ == "__main__":
    print(" Smart Health Monitoring System (Data Simulation)")
    try:
        while True:
            data = generate_health_data()
            insert_data_to_db(data)
            print(f"[{data[0]}] HR: {data[1]} bpm, Temp: {data[2]}°F, SpO2: {data[3]}%, Stress: {data[4]}")
            time.sleep(5)  
    except KeyboardInterrupt:
        print("\n Stopped by user.")
    finally:
        conn.close()

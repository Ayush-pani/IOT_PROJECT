from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

def get_health_data():
    conn = sqlite3.connect("health_data.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM health_monitor ORDER BY id DESC LIMIT 20")
    rows = cursor.fetchall()
    conn.close()
    return rows

@app.route("/")
def index():
    data = get_health_data()
    return render_template("index.html", data=data) 

if __name__ == "__main__":
    app.run(debug=True)
